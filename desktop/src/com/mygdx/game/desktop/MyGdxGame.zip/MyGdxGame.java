package com.mygdx.game.desktop;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import org.lwjgl.Sys;

import java.util.ArrayList;
import java.util.List;

public class MyGdxGame extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img,invader,bullet,load1,load2;
	Sprite sprite,ship,loading,start;
	//new ship
	private Ship shipx = new Ship();
	private List<Bult> bullyts = new ArrayList<Bult>();
	private List<Monster> monsters = new ArrayList<Monster>();
	//fire timer
	private int timer2 = 0;
	// pause
	private String Status = "game";
	// ship x,y
	private int xPos = 0;
	private int yPos = 0;
	//score
	private int score = 0;
	// movement timer
	private int bling;
	private long timeLapse, previousTime;
	//monsterr move
	private int timer;
	private boolean MosnterRight = true,prevent=true;

	// which way?
	private boolean right = true;
	//monster field
	private List<Integer>monsterx = new ArrayList<Integer>();
	private List<Integer>monstery = new ArrayList<Integer>();
	public int inted(Object a ){
		return  Integer.parseInt(a.toString());
	}
	public float floated(Object a){
		return (float)(inted(a));
	}
	public void createM(){
		img = new Texture("imgs/monster.png");
		invader = new Texture("imgs/invader.jpg");

		int x = 0;
		int y = 900;
		for(int i = 0; i<8 ; i++){
			for(int k = 0; k < 11 ; k++){
				Monster a = new Monster();
				a.Set(x,y);
				a.SetImg(img,invader);
				x+=60;
				if(x==660){
					x=0;
				}
				monsters.add(a);
			}
			y-=60;
		}
	}
	@Override
	public void create () {
		createM();
		Gdx.graphics.setWindowedMode(1200, 1000);
		batch = new SpriteBatch();
		img = new Texture("imgs/monster.png");
		invader = new Texture("imgs/invader.jpg");
		bullet = new Texture("imgs/bullet.jpg");
		load1 = new Texture("imgs/loading2.png");
		//System.out.println(Gdx.graphics.getWidth() + "," + Gdx.graphics.getHeight());

		shipx.LoadImg(invader);

		ship = new Sprite(invader);
		sprite = new Sprite(img);
		start = new Sprite(load1);
		ship.setPosition(xPos,yPos);
		previousTime = System.currentTimeMillis();
	}

	@Override
	public void render () {
		//loading
		if(Status.equals("loading")){
			start.setPosition(385,682);
			batch.begin();
			start.draw(batch);
			batch.end();
			if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
				Status = "game";
			}
		}
		//pause
		if(Status.equals("pause")){
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			ship.setPosition(200,500);
			batch.begin();
			ship.draw(batch);
			batch.end();
			if(Gdx.input.isKeyJustPressed(Input.Keys.SPACE)&&timer2>500){
				timer2=0;
				Status = "game";
			}
			timer2+=10 ;
		}
		if(Status.equals("game")) {
			//pause key
			if(Gdx.input.isKeyJustPressed(Input.Keys.SPACE)&&timer2>=300){
				Status = "pause";
				timer2 = 0;
			}
			//colli
			for(int i =0;i<bullyts.size();i++){

				Rectangle bul = bullyts.toArray(new Bult[bullyts.size()])[i].Getimg().getBoundingRectangle();
				for(int k = 0;k<monsters.size();k++){

					Rectangle monsteR = monsters.toArray(new Monster[monsters.size()])[k].Getimg()
							.getBoundingRectangle();
					if(monsteR.overlaps(bul)){
						monsters.remove(k);
						bullyts.remove(i);
						score++;
						System.out.println(score);
					}
				}
			}

			// monster moves
			timeLapse = System.currentTimeMillis() - previousTime;

			for(int i =0;i<monsters.size();i++){
				if(monsters.toArray(new Monster[monsters.size()])[i].Touch()&&!prevent){
					MosnterRight = false;
					System.out.println(2);
					break;
				}
			}
			if(MosnterRight&&timer >= 5000){
				for(int i =0;i<monsters.size();i++){
					monsters.toArray(new Monster[monsters.size()])[i].Move();
					prevent = false;
				}
				timer =0;

			}
			else if(!MosnterRight &&!prevent&&timer >= 5000){
				for(int i =0;i<monsters.size();i++){
					monsters.toArray(new Monster[monsters.size()])[i].MoveDown();
					monsters.toArray(new Monster[monsters.size()])[i].OtherWay();
					MosnterRight = true;
					prevent= true;
				}
				timer =0;
			}
			timer+=50;
			// key press
			if (Gdx.input.isKeyPressed(Input.Keys.A)) {
				// use translate(vx,vy), translateX(vx) or translateY(vy)
				if(shipx.GetX()>0) {
					shipx.MoveLeft();
				}
			}
			if (Gdx.input.isKeyPressed(Input.Keys.D)) {
				// use translate(vx,vy), translateX(vx) or translateY(vy)
				if(shipx.GetX()<1000) {
					shipx.MoveRight();
				}
			}
			if(Gdx.input.isKeyPressed(Input.Keys.S)){
				if(shipx.shot()) {
					Bult e = new Bult();
					e.Set(shipx.GetX(),shipx.GetY());
					e.SetGift(bullet);
					e.LoadImg();
					bullyts.add(e);
					shipx.ReSet();
				}
			}
			if(bling > 10){
				for(int i  = 0;i<monsters.size();i++){
					monsters.toArray(new Monster[monsters.size()])[i].Bling();
				}
				bling = 0;
			}
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			ship.setPosition(xPos, yPos);
			// move bullet
			for(int i = 0;i<bullyts.size();i++){
				bullyts.toArray(new Bult[bullyts.size()])[i].Moving();
			}
			//draw everything
			batch.begin();
			for(int i = 0;i<bullyts.size();i++){
				bullyts.toArray(new Bult[bullyts.size()])[i].ShowBullt(batch);
			}
			for(int i  = 0;i<monsters.size();i++){
				monsters.toArray(new Monster[monsters.size()])[i].ShowMonster(batch);
			}
			shipx.ShowShip(batch);
			batch.end();
			timer+=20;
			if(monsters.size() == 0){
				Status = "pause";
			}
			timer2+=100;
			bling++;
			shipx.Charge();
		}
	}
}
class Ship{
	private int Posx, Posy;
	private int ShotTime;
	private int Lives=3;
	private Sprite Img;
	public Sprite Getimg(){
		return Img;
	}
	public void LoadImg(Texture k){
		Img = new Sprite(k);
	}
	public int GetX(){
		return Posx;
	}
	public int GetY(){
		return Posy;
	}

	public void MoveRight(){
		Posx+=5;
	}
	public void MoveLeft(){
		Posx-=5;
	}
	public void ReSet(){
		ShotTime = 0;
	}
	public void Charge(){
		ShotTime +=5;
	}
	public boolean shot(){
		if(ShotTime > 100){
			return true;
		}
		else{
			return false;
		}
	}
	public void ShowShip(SpriteBatch batch){
		Img.setPosition((float)(Posx),(float)(Posy));
		Img.draw(batch);
	}
}
class Bult{
	private int Posx,Posy,Speed = 5;
	private Texture Text;
	private Sprite Img;
	public Sprite Getimg(){
		return Img;
	}
	public void Set(int x,int y){
		Posx =x;
		Posy =y;
	}
	public void SetGift(Texture A){
		Text = A;
	}
	public void LoadImg(){
		Img = new Sprite(Text);
	}
	public void Moving(){
		Posy += Speed;
	}
	public void ShowBullt(SpriteBatch batch){
		Img.setPosition((float)(Posx),(float)(Posy));
		Img.draw(batch);
	}
}
class Monster{
	private int Posx,Posy,Speedx=50,Speedy=50,num=1;
	private Texture Text,preText;
	private Sprite Img;
	private boolean MoveDown;
	public Sprite Getimg(){
		return Img;
	}
	public void Set(int x,int y){
		Posx =x;
		Posy =y;
	}
	public void SetImg(Texture a,Texture b){
		Text = a;
		preText = b;
		Img = new Sprite(Text);
	}

	public void Move(){
		Posx+=Speedx;
	}
	public void OtherWay(){
		Speedx = -Speedx;
	}
	public void MoveDown(){
		Posy-=Speedy;
	}
	public boolean Touch(){
		if(Posx < 0||Posx>1000){
			return true;
		}
		else {
			return false;
		}
	}
	public void Bling(){
		if(num==1){
			Img = new Sprite(preText);
			num =2;
		}
		else{
			Img = new Sprite(Text);
			num = 1;
		}
	}
	public void ShowMonster(SpriteBatch batch){
		Img.setPosition((float)(Posx),(float)(Posy));
		Img.draw(batch);
	}
}
